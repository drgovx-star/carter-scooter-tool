CART3R SCOOTER TOOL — iPhone PWA

DEPLOY FROM IPHONE USING GITHUB PAGES
1. In Safari, sign in or create an account at https://github.com.
2. Create a NEW PUBLIC repository named carter-scooter-tool.
3. Open the repository, choose Add file > Upload files.
4. Upload ALL five files from this ZIP: index.html, manifest.json, sw.js, icon-192.png, icon-512.png.
   You may need to unzip the download in the iPhone Files app first.
5. Commit the uploaded files to the main branch.
6. In repository Settings > Pages, under Build and deployment choose Deploy from a branch.
7. Select branch main and folder /(root), then Save.
8. Wait for GitHub Pages to publish. Open the Pages URL shown in Settings > Pages in Safari.
9. Tap Share (square with arrow) > Add to Home Screen > Add.

WHAT IT DOES
- Dashboard and scooter profile
- Local diagnostic checklist
- Local notes/log
- Offline cache after first successful load (once served over HTTPS)

LIMITATIONS
- This browser app does not connect to the scooter over Bluetooth or USB.
- iOS Safari does not support generic Web Bluetooth access to arbitrary BLE devices.
- It does not read live telemetry, unlock speed, alter motor/brakes, or flash firmware.
- USB support requires a compatible native app/accessory/protocol; a cable alone is insufficient.
- Profile and notes are stored in Safari website data on this iPhone. Clearing website data may erase them.

Keep your scooter stationary while performing inspections. Follow local road regulations.
